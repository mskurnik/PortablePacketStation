
const char ProductName[] = "ARDOP TNC";
const char ProductVersion[] = "2.0.3.40-BPQ-OFDM";

// 3.32 Fix tuning range
// 3.33 Add GUI Support
// 3.34 Improve GUI Support
//		Add L/R soundcard and LOGDIR Options
// 3.35	Improvements to ARQ timing
// 3.36	Add short (~2Sec) 4PSK mode for sending < 120 bytes of data
// 3.37 Fix switching back from more robust mode if data outstanding
// 3.38 Temporary disable Short frame sending stuff
// 3.39 Fix shift error in 38
// 3.40 Add EXTRADELAY parameter
