//
//	Makes keeping Windows, Linux and Teensy version in step easier

#define TEENSY
#define ARDOP
#define PTC

#include "TeensyConfig.h"

#include "../../ARDOP3K/ARDOPC.c"
#include "../../ARDOP3K/ardopSampleArrays.c"
#include "../../ARDOP3K/ARQ.c"
#include "../../ARDOP3K/berlekamp.c"
#include "../../ARDOP3K/BusyDetect.c"
#include "../../ARDOP3K/FEC.c"
#include "../../ARDOP3K/FFT.c"
#include "../../ARDOP3K/KISSModule.c"
#include "../../ARDOP3K/galois.c"
#include "../../ARDOP3K/HostInterface.c"
#include "../../ARDOP3K/Modulate.c"
#include "../../ARDOP3K/rs.c"
#include "../../ARDOP3K/SCSHostInterface.c"
#include "../../ARDOP3K/SoundInput.c"
//#include "../../ARDOP3/direwolf/demod_afsk.c"
//#include "../../ARDOP3/direwolf/dsp.c"
//#include "../../ARDOP3/direwolf/hdlc_rec.c"
#include "../../ARDOP3K/afskModule.c"
//#include "../../ARDOP3/costab.c"
//#include "../../ARDOP3/modem.c"
#include "../../ARDOP3K/pktARDOP.c"
#include "../../ARDOP3K/pktSession.c"
#include "../../ARDOP3K/Viterbi.c"
#include "../../ARDOP3K/ackbycarrier.c"
