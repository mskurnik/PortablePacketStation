
#define ProductName "ARDOP TNC"
//#define ProductVersion "3.0.1.18j-BPQ"
#define ProductVersion "3.0.1.18k-BPQ"	// 19/6
