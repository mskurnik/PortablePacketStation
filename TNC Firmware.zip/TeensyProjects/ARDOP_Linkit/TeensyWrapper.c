//
//	Makes keeping Windows, Linux and Teensy version in step easier

#define TEENSY
#define ARDOP
#define PTC

#include "LinkitConfig.h"
#include "ConfigARDOP.h"

#define LED1 36
#define LED2 36
#define LED3 36
#define LED4 36


#include "../../ARDOPC/ARDOPC.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/ardopSampleArrays.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/ARQ.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/berlekamp.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/BusyDetect.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/FEC.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/FFT.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/KISSModule.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/galois.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/HostInterface.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/Modulate.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/rs.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/SCSHostInterface.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/SoundInput.c"
//#include "../../ARDOPC/direwolf/demod_afsk.c"
//#include "../../ARDOPC/direwolf/dsp.c"
//#include "../../ARDOPC/direwolf/hdlc_rec.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/afskModule.c"
//#include "../../ARDOPC/costab.c"
//#include "../../ARDOPC/modem.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/pktARDOP.c"
#include "C:\OneDrive\Dev\Source\TeensyProjects\ARDOPC/pktSession.c"

