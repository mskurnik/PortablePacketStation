//
//	Makes keeping Windows, Linux and Teensy version in step easier

#define TEENSY
#define ARDOP
#define PTC

#include "TeensyConfig.h"

#include "../../ARDOPC/ARDOPC.c"
#include "../../ARDOPC/ardopSampleArrays.c"
#include "../../ARDOPC/ARQ.c"
#include "../../ARDOPC/berlekamp.c"
#include "../../ARDOPC/BusyDetect.c"
#include "../../ARDOPC/FEC.c"
#include "../../ARDOPC/FFT.c"
#include "../../ARDOPC/KISSModule.c"
#include "../../ARDOPC/galois.c"
#include "../../ARDOPC/HostInterface.c"
#include "../../ARDOPC/Modulate.c"
#include "../../ARDOPC/rs.c"
#include "../../ARDOPC/SCSHostInterface.c"
#include "../../ARDOPC/SoundInput.c"
//#include "../../ARDOPC/direwolf/demod_afsk.c"
//#include "../../ARDOPC/direwolf/dsp.c"
//#include "../../ARDOPC/direwolf/hdlc_rec.c"
//#include "../../ARDOPC/afskModule.c"
//#include "../../ARDOPC/costab.c"
//#include "../../ARDOPC/modem.c"
#include "../../ARDOPC/pktARDOP.c"
#include "../../ARDOPC/pktSession.c"



#include "../../Soundmodem\afsk\costab.c"
#include "../../Soundmodem\frchol.c"
#include "../../Soundmodem\frmul.c"
#include "../../Soundmodem\frtransp.c"
#include "../../Soundmodem\kisspkt.c"
#include "../../Soundmodem\main.c"
#include "../../Soundmodem\afsk\modem.c"
#include "../../Soundmodem\rctime.c"
#include "../../Soundmodem\rrctime.c"
#include "../../Soundmodem\simd.c"
#include "../../Soundmodem\vsnprintf.c"
