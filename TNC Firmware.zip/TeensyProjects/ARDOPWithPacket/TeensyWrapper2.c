//
//	Makes keeping Windows, Linux and Teensy version in step easier

#define TEENSY

#define UCHAR unsigned char
#define BOOL int
#define TRUE 1
#define FALSE 0


#include "../../Soundmodem\fsk\fskic.c"
#include "../../Soundmodem\fsk\modem.c"
#include "../../Soundmodem\sinc.c"
